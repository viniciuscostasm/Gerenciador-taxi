<?php

/**
 * Classe mãe para exibição do rodapé da página
 */
class GFooterParent {
    function show() {
        $echo .= '</html>';
        echo $echo;
    }
}