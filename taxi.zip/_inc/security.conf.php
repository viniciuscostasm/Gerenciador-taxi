<?php
// Conexões com o banco de dados
if ($_SERVER['SERVER_NAME'] == 'localhost' || strpos($_SERVER['SERVER_NAME'], '192.168') !== false || strpos($_SERVER['SERVER_NAME'], '10.') !== false) {
    define('SERVER', 'D');
    define('MYSQL_HOST', '192.168.0.13');
    define('MYSQL_PORT', '3306');
    define('MYSQL_USER', 'continentaltaxi');
    define('MYSQL_PASS', 'num3r0l0g14');
    define('MYSQL_BASE', 'continentaltaxi');
    define('MYSQL_CHARSET', 'utf8');
    define('MYSQL_TIMEZONE', '-03:00');
    define('PHP_TIMEZONE', 'America/Bahia');
} else if (strpos($_SERVER['SERVER_NAME'], 'continentaltaxi.inactu.com.br') !== false || strpos($_SERVER['SERVER_NAME'], '10.') !== false) {
    define('SERVER', 'D');
    define('MYSQL_HOST', 'mysql.inactu.com.br');
    define('MYSQL_PORT', '3306');
    define('MYSQL_USER', 'inactu71');
    define('MYSQL_PASS', 'num3r0l0g14');
    define('MYSQL_BASE', 'inactu71');
    define('MYSQL_CHARSET', 'utf8');
    define('MYSQL_TIMEZONE', '-03:00');
    define('PHP_TIMEZONE', 'America/Sao_Paulo');
} else if (strpos($_SERVER['SERVER_NAME'], 'continental.com') !== false) {
    define('SERVER', 'D');
    define('MYSQL_HOST', '');
    define('MYSQL_PORT', '3306');
    define('MYSQL_USER', '');
    define('MYSQL_PASS', '');
    define('MYSQL_BASE', '');
    define('MYSQL_CHARSET', 'utf8');
    define('MYSQL_TIMEZONE', '-03:00');
    define('PHP_TIMEZONE', 'America/Sao_Paulo');
}
